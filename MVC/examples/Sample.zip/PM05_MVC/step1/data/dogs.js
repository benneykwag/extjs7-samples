{"entitys":[
	{"name":"진도개","age":"1","imgUrl":"imgs/dog1.jpg"},
	{"name":"세퍼트","age":"1","imgUrl":"imgs/dog2.jpg"},
	{"name":"치와와","age":"1","imgUrl":"imgs/dog3.jpg"},
	{"name":"말라뮤트","age":"1","imgUrl":"imgs/dog4.jpg"}
	],"errMsg":"","errTitle":"검색결과","message":"","success":true,"totalCount":"6"}