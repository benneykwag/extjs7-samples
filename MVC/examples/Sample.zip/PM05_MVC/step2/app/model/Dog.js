Ext.define('dog.model.Dog', {
    extend : 'Ext.data.Model',
    fields : ['name', 'type','age','imgUrl']
})