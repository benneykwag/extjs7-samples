Ext.application({
    extend: 'dog.Application',
    name : 'dog',
    autoCreateViewport: true
});