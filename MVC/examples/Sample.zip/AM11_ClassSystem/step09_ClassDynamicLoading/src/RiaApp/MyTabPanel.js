Ext.define('RiaApp.MyTabPanel', {
    extend : 'Ext.tab.Panel',
    xtype : 'mytabpanel',
    items : [{
        xtype : 'panel',
        title : 'aaa'
    },{
        xtype : 'panel',
        title : 'aaa'
    }]
})